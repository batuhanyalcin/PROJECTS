//
//  EnteranceViewController.swift
//  391TeamProject
//
//  Created by Lab on 30.11.2021.
//

import UIKit
import FirebaseAnalytics
import Firebase
import FirebaseAuth
import FirebaseFirestore

class EnteranceViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "Sign In"
       
        styleObject() //called object style
    }
    
    func styleObject() {
        password.isSecureTextEntry = true
        errorLabel.alpha = 0 // error label not visible
    }
    
    
    
    @IBAction func signInPress(_ sender: Any) {
        
        //Getting Email and Passweord
        let email = email.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = password.text!.trimmingCharacters(in: .whitespacesAndNewlines)
    
        //Firebase sign function
        Auth.auth().signIn(withEmail: email, password: password) { (result, errorSignIn) in
           
            //Check for error
            if errorSignIn != nil {
                self.errorLabel.text = errorSignIn?.localizedDescription
                self.errorLabel.alpha = 1
                self.navigationController?.popToRootViewController(animated: true)
                self.dismiss(animated: true, completion: nil);
            } else {
                self.errorLabel.text = "Welcome Again"
                self.errorLabel.textColor = UIColor.systemGreen
                self.errorLabel.alpha = 1
                let screen = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "MainScreen") as? MainViewController
                self.navigationController?.pushViewController(screen!, animated: true)
                 }
            }
        }
}
    


