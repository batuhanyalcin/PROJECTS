//
//  ViewController.swift
//  wheel
//
//  Created by Lab on 17.01.2022.
//

import UIKit
import gRPC_Core

class WheelViewController: UIViewController {
    @IBOutlet weak var wheel: UIImageView!
    var angVel: Double = 0
    var prevY: Double = 0
    var currY: Double = 0
    var angle: Float = 0.0
    var passUse: Bool=false
    var use2x: Bool=false
    var gameHelper: GameHelper = GameHelper()
    let defaults = UserDefaults.standard
    
    @IBOutlet weak var highScoreLabel: UILabel!
    @IBOutlet weak var spinButton: UIButton!
    @IBOutlet weak var passButon: UIButton!
    @IBOutlet weak var use2xButton: UIButton!
    @IBOutlet weak var turnWheelButton: UIButton!
    @IBOutlet weak var takeMoneyButton: UIButton!
    @IBOutlet weak var totalMoneyLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let highScore = defaults.integer(forKey: "HighScore")
        self.highScoreLabel.text = "HighScore: $ \(highScore)"
        self.takeMoneyButton.isEnabled = false
        self.totalMoneyLabel.text = "Total money: $500"
        self.gameHelper.resetGame()
        self.use2xButton.configuration = self.configUse2x()
        self.passButon.configuration = self.configPass()
        self.passButon.isEnabled = false
    }
    func configPass() -> UIButton.Configuration {
        var config:UIButton.Configuration = .filled()
        config.baseBackgroundColor = .systemGreen
        config.title = "Use Pass"
        config.subtitle = "Remaining: \(gameHelper.totalPass)"
        return config
    }
    
    func configUse2x() -> UIButton.Configuration {
        var config:UIButton.Configuration = .filled()
        config.baseBackgroundColor = .systemYellow
        config.title="Use 2x"
        config.subtitle = "Remaining: \(gameHelper.totalUse2x)"
        return config
    }
    @IBAction func use2xButton(_ sender: Any) {
        if !use2x {
            gameHelper.use2XUsed()
            use2xButton.configuration = configUse2x()
            if gameHelper.totalUse2x==0{
                use2xButton.isEnabled = false
            }
        }
        use2x = true
        
    }
    
    @IBAction func turnWheelButton(_ sender: UIButton) {
        //print("Initial angle: \(self.angle)")
        
        gameHelper.increaseNumberOfSpins()
        passUse = false
        var i = Int.random(in: 6...10)
        i = 2*i
        let angle = Float.random(in: 0...2*Float.pi);
        UIView.animate(withDuration: 5) {

            for _ in 1...i {
                self.wheel.transform = self.wheel.transform.rotated(by: CGFloat(Float.pi))
                
            }
            self.wheel.transform = self.wheel.transform.rotated(by: CGFloat(angle))
            self.angle += angle
            
            let wheelScore = self.gameHelper.calculateScore(angle: self.angle)
            self.gameHelper.savePrevScore()
            if (self.use2x) {
                self.gameHelper.score += wheelScore*2
                self.use2x = false
            }
            else {
                self.gameHelper.score += wheelScore
            }
          
            let isUse2xEnabled = self.use2xButton.isEnabled
            let isPassEnabled = self.passButon.isEnabled
            self.use2xButton.isEnabled = false
            self.passButon.isEnabled = false
            self.turnWheelButton.isEnabled = false
            self.takeMoneyButton.isEnabled = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                self.totalMoneyLabel.text=" Total Money: $ \(self.gameHelper.score)"
                self.turnWheelButton.isEnabled = true
                self.passButon.isEnabled = isPassEnabled
                self.use2xButton.isEnabled = isUse2xEnabled
                self.takeMoneyButton.isEnabled = true
                
                let highScore = self.defaults.integer(forKey: "HighScore")
                if highScore < self.gameHelper.score {
                    self.takeMoneyButton.isEnabled = true
                }
                else {
                    self.takeMoneyButton.isEnabled = false
                    
                }
                
                if self.gameHelper.numberOfSpins == 1 {
                    self.passButon.isEnabled = true
                }
                
                if self.gameHelper.score <= 0 {
                   
                    self.totalMoneyLabel.text = "Total money: $500"
                    self.gameHelper.resetGame()
                    self.use2xButton.configuration = self.configUse2x()
                    self.passButon.configuration = self.configPass()
                    self.passButon.isEnabled = false
                    
                    if let vc = self.storyboard?.instantiateViewController(withIdentifier: "Bankrupt") {
                        vc.modalTransitionStyle = .coverVertical
                        vc.modalPresentationStyle = .popover
                        self.present(vc, animated: true, completion: nil)
                    }
                    
                }
            }
        }
        use2x = false
        
    }
    @IBAction func usePass(_ sender: Any) {
        if !passUse {
            self.gameHelper.score = self.gameHelper.prevScore
            
            self.gameHelper.totalPass-=1
            passButon.configuration = configPass()
            //passButon.subtitleLabel.="Remaining: \(totalPass)"
        }
        passUse = true

        if self.gameHelper.totalPass==0{
            passButon.isEnabled = false
        }
        self.totalMoneyLabel.text=" Total Money: $ \(self.gameHelper.score)"
        if self.gameHelper.score <= 0 {
            self.totalMoneyLabel.text = "Total money: $500"
            self.gameHelper.resetGame()
            self.use2xButton.configuration = self.configUse2x()
            self.passButon.configuration = self.configPass()
            self.passButon.isEnabled = false
            let screen = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "Bankrupt") as? BankruptViewController //next Account scrren
            self.navigationController?.pushViewController(screen!, animated: true)
        }
    }
    
    @IBAction func takeMoney(_ sender: Any) {
        let highScore = defaults.integer(forKey: "HighScore")
        self.takeMoneyButton.isEnabled = false
        
        if highScore < self.gameHelper.score {
            self.defaults.set(self.gameHelper.score, forKey: "HighScore")
            self.highScoreLabel.text = "HighScore: $ \(self.gameHelper.score)"
            self.totalMoneyLabel.text = "Total money: $ 500"
            self.gameHelper.resetGame()
            self.use2xButton.configuration = self.configUse2x()
            self.passButon.configuration = self.configPass()
            self.passButon.isEnabled = false
        } /*
        else {
            self.totalMoneyLabel.text = "Total money: $500"
            self.gameHelper.resetGame()
            self.use2xButton.configuration = self.configUse2x()
            self.passButon.configuration = self.configPass()
            self.passButon.isEnabled = false
        }
           */
    }

    

}


