//
//  ViewController.swift
//  391TeamProject
//
//  Created by Lab on 30.11.2021.
//

import UIKit

//Main screen of the Game

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        
        // Do any additional setup after loading the view.
    }


}


