//
//  TopTenViewController.swift
//  391TeamProject
//
//  Created by Lab on 30.11.2021.
//

import UIKit


//List of Top Ten user which get significant amount of money
class TopTenViewController: UIViewController {
    
    var userDataSource = UserDataSource()
    
    @IBOutlet weak var topTenTableView: UITableView!
    
    //Initilaze screen
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Top 10 List"
        
        // Additional setup after loading the view.
        userDataSource.delegate = self
        userDataSource.getUserData()
    }
    

    // Preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // Gets the new view controller using segue.destination.
        // Passes the selected object to the new view controller.
        let cell = sender as! TopTenTableViewCell
        if let indexPath = self.topTenTableView.indexPath(for: cell) {
            let user = userDataSource.getUserWithIndex(index: getRealIndex(indexPath: indexPath))
            let userDetailViewController = segue.destination as! DetailViewController
            userDetailViewController.selectedUser = user
        }
    }
    
    //gGets index in Int
    func getRealIndex(indexPath: IndexPath) -> Int {
        let realIndex = indexPath.row.quotientAndRemainder(dividingBy: userDataSource.getNumberOfUsers()).remainder
        return realIndex
    }
}

//Extension for getting data
extension TopTenViewController: UserDataSourceDelegate {
    func userDetailLoaded() {
        topTenTableView.reloadData()
    }
    

}

//Extension for table view roes
extension TopTenViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userDataSource.getNumberOfUsers()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TopTenCell", for: indexPath) as! TopTenTableViewCell
        let user = userDataSource.getUserWithIndex(index: getRealIndex(indexPath: indexPath))
        cell.userImageView.image = UIImage(named: user.imageName)
        cell.userNameLabel.text = user.nickname
        return cell
    }
    

}

//Extension for scrolling
extension TopTenViewController: UIScrollViewDelegate {

    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        if (velocity.y != 0 || velocity.x != 0) {
            let reminder = targetContentOffset.pointee.y.truncatingRemainder(dividingBy: 90.5)
            let previousPoint = targetContentOffset.pointee
            targetContentOffset.pointee = CGPoint(x: previousPoint.x, y: previousPoint.y - reminder)
        }
    }
}
