//
//  collectionViewController.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import UIKit


// Shop screen of the game


class CollectionViewController: UIViewController {
    
    
    let powerShopDataSource = PowerShopDataSource()

   //Takes collection view
    
   @IBOutlet weak var CarCollectionView: UICollectionView!
    
    //initliaze the screen
    override func viewDidLoad() {
        super.viewDidLoad()
        powerShopDataSource.delegate = self
        powerShopDataSource.getPowerupsData()
        
        // Do any additional setup after loading the view.
    }
    
    /*override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let item = sender as! collectionCollectionViewCell
        if let indexPath = self.CarCollectionView.indexPath(for: item) {
            let realIndex = indexPath.row.quotientAndRemainder(dividingBy: powerShopDataSource.getNumberOfPowerups()).remainder
            let powerups = powerShopDataSource.getPowerupsWithIndex(index: realIndex)
            
        }
    }*/
    
}

extension CollectionViewController: PowerupsShopDataSourceDelegate{
    func powerupsLoaded() {
    CarCollectionView.reloadData()
    }
    
}

//Extension for communicate with the view cell

extension CollectionViewController: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return powerShopDataSource.getNumberOfPowerups()
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewCell", for: indexPath) as! CollectionCollectionViewCell
        let powerups = powerShopDataSource.getPowerupsWithIndex(index: indexPath.row)
        item.powerupsImageView.image = UIImage(named: powerups.imageName)
        item.quantityLabel.text = "Amount: \(powerups.quantity)"
        item.priceLabel.text = "\(powerups.price) $"
        return item
    }
    
    

}
