//
//  SignOutViewController.swift
//  391TeamProject
//
//  Created by Lab on 18.01.2022.
//

import UIKit

class UserInfoViewController: UIViewController {
    
    let userDataSource = UserDataSource()

    @IBOutlet weak var firstNameLabel: UITextField!
    @IBOutlet weak var lastNameLabel: UITextField!
    @IBOutlet weak var nickNameLabel: UITextField!
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var passLabel: UITextField!
    @IBOutlet weak var use2xLabel: UITextField!
    @IBOutlet weak var scoreLabel: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "User Info"
        userDataSource.delegate = self
    
    }
    
}
    
extension UserInfoViewController: UserDataSourceDelegate {
    func userDetailLoaded() {
        
    }
    
    
        func userDetailLoaded(user: User) {
            self.firstNameLabel.text = " \(user.firstName)"
            self.lastNameLabel.text = " \(user.lastName)"
            self.nickNameLabel.text = " \(user.nickname)"
            self.emailLabel.text = " \(user.email)"
            self.passLabel.text = " \(user.pass)"
            self.use2xLabel.text = " \(user.use2x)"
            self.scoreLabel.text = " \(user.score)"
        }
    }
    
    
    
    
    


