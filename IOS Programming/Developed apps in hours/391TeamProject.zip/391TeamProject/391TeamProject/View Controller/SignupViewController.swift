//  ViewController.swift
//  391TeamProject
//
//  Created by Lab on 30.11.2021.
//

import UIKit
import FirebaseAnalytics
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase


class SignupViewController: UIViewController {

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var nickname: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    
    private let database=Database.database().reference()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "Sign Up"
        styleObject()
    }
    
    func styleObject() {
        password.isSecureTextEntry = true
        errorLabel.alpha = 0
    }
    
    func checkFields() -> String? {
        // if areas null, return error message
        if (nickname.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            firstName.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            lastName.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            email.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            password.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "") {
            return "Make sure that all the fields are filled."
        }
        //Standart error message
        if validPassword(password.text!.trimmingCharacters(in: .whitespacesAndNewlines)) == false {
            return "Make sure that your password should include at least 8 characters, a special character($@$#!%*?&.), english character and a number."
        }
        return nil
    }
    
    func validPassword(_ password : String) -> Bool {
        return NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[$@$#!%*?&.])[A-Za-z\\d$@$#!%*?&.]{8,}").evaluate(with: password)
    }
    

    @IBAction func SignUpPress(_ sender: Any) {
        
        let errorFields = checkFields() //called error
        
        if errorFields != nil { // if conditions are not valid, check this function
            self.disaplayErrorMessage(errorFields!)
        } else {
            let name = firstName.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let surname = lastName.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let email = email.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let password = password.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let nickname_store = nickname.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            Auth.auth().createUser(withEmail: email, password: password) { (result, errorLoginImformation) in
            
                if errorLoginImformation != nil {
                    self.disaplayErrorMessage("User couldn't be created.")
                } else {
                    let dataBase = Firestore.firestore()
                    dataBase.collection("user").document(result!.user.uid ).setData(["firstName":name, "lastName":surname, "email":email, "nickname":nickname_store, "uid": result!.user.uid, "pass" : 0, "use2x" : 0, "score" : 0, "imageName" : "lion" ]) { (errorDataBase) in
                        if errorDataBase != nil {
                            self.disaplayErrorMessage("Couldn't reach database")
                        } else { // Account created
                            self.errorLabel.text = "Registration Successful"
                            self.errorLabel.textColor = UIColor.systemGreen
                            self.errorLabel.alpha = 1
                            let screen = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "MainScreen") as? MainViewController
                            self.navigationController?.pushViewController(screen!, animated: true)
                        }
                    }
                }
            }
            
        }
    }
    
    
    
    
    
    
    
    func disaplayErrorMessage(_ theMessage:String) //error label function 
    {
        let alert = UIAlertController(title: "Alert", message: theMessage, preferredStyle: UIAlertController.Style.alert);
        let okButton = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default) {
            action in
        }
        alert.addAction(okButton);
        self.present(alert, animated: true, completion: nil)
    }
    

}

