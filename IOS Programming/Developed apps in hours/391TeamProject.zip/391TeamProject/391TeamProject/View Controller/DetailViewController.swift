//
//  detailViewController.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import UIKit

class DetailViewController: UIViewController {
    
    var selectedUser: User?

    //@IBOutlet weak var carModelLabel: UILabel!
    @IBOutlet weak var userView: UIImageView!
    @IBOutlet weak var userScore: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = "\(selectedUser?.firstName ?? "BATUHAN") \(selectedUser?.lastName ?? "YALÇIN")"
        if let User = selectedUser {
            self.userScore.text = "\(User.score)"
            self.userView.image = UIImage(named: User.imageName)
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
