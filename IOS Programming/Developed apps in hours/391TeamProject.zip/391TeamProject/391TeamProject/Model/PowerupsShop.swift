//
//  PowerupsShop.swift
//  391TeamProject
//
//  Created by Lab on 17.01.2022.
//

import Foundation

// For powerups choices in shop (Offers)

struct PowerupsShop: Codable {
    let Name: String
    let quantity: Int
    let price: Int
    let imageName: String
}
