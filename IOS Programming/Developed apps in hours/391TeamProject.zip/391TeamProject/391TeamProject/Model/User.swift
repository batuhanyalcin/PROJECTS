//
//  User.swift
//  391TeamProject
//
//  Created by Lab on 30.11.2021.
//
import Foundation


//This are players data struct to store and use their data

struct User: Codable {
    let email: String
    let firstName: String
    let lastName: String
    let nickname: String
    let pass: Int
    let use2x: Int
    let score: Int
    let imageName: String

}
