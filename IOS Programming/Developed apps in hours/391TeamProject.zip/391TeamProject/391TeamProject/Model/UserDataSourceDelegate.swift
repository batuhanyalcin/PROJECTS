//
//  UserDataSourceDelegate.swift
//  391TeamProject
//
//  Created by Lab on 30.11.2021.
//

import Foundation

//Intiliazs delegate
protocol UserDataSourceDelegate{
    func userDetailLoaded()
    
}
