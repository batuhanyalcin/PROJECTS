//
//  UserDataSource.swift
//  391TeamProject
//
//  Created by Lab on 30.11.2021.
//

import Foundation
import FirebaseDatabase
import FirebaseFirestore


class UserDataSource{
    
    let dataBase = Firestore.firestore()
    private var userArray: [User] = []
    var delegate: UserDataSourceDelegate?
    
    
    func getUserData() {
         dataBase.collection("user").addSnapshotListener { querySnapshot, err in
                  if let error = err {
                      print(error)
                  } else {
                      for data in querySnapshot?.documents ?? [] {
                          self.userArray.append(User(email: data["email"] as? String ?? "",
                                                     firstName: data["firstName"] as? String ?? "",
                                                     lastName: data["lastName"] as? String ?? "",
                                                     nickname: data["nickname"] as? String ?? "",
                                                     pass: data["pass"] as? Int ?? 0,
                                                     use2x: data["use2x"] as? Int ?? 0,
                                                     score: data["score"] as? Int ?? 0,
                                                     imageName: data["imageName"] as? String ?? ""))
                      DispatchQueue.main.async {
                          self.delegate?.userDetailLoaded()
                    
                          
                      }
                  }
              }
      }
    }
    
    
    
    func getNumberOfUsers() -> Int {
        print(userArray.count)
        return userArray.count
    }
    
    func getUserWithIndex(index: Int) -> User {
        return userArray[index]
    }
    
    
}


