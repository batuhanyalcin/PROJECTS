//
//  UserDataSource.swift
//  391TeamProject
//
//  Created by Lab on 30.11.2021.
//

import Foundation
import FirebaseDatabase
import FirebaseFirestore


class PowerShopDataSource{
    
    let dataBase = Firestore.firestore()
    private var powerupArray: [PowerupsShop] = []
    private let baseURL = "https://koc.api.staging.tarentum.io"
    var delegate: PowerupsShopDataSourceDelegate?
    
    
    
    func getPowerupsData() {
         dataBase.collection("powerups").addSnapshotListener { querySnapshot, err in
                  if let error = err {
                      print(error)
                  } else {
                      for data in querySnapshot?.documents ?? [] { //visit all meal
                          let option = (PowerupsShop(Name: data["Name"] as? String ?? "",
                                                     quantity: data["quantity"] as? Int ?? 0,
                                                     price: data["price"] as? Int ?? 0,
                                                     imageName: data["imageName"] as? String ?? ""))
                          self.powerupArray.append(option)
                      DispatchQueue.main.async {
                          self.delegate?.powerupsLoaded()
                          print(option.Name)
                          
                      }
                  }
              }
      }
    }
    
    
    func getNumberOfPowerups() -> Int {
        print(powerupArray.count)
        return powerupArray.count
    }
    
    func getPowerupsWithIndex(index: Int) -> PowerupsShop {
        return powerupArray[index]
    }
    

}


