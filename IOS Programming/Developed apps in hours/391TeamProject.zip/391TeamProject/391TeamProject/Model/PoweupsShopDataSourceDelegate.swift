//
//  PoweupsShopDataSourceDelegate.swift
//  391TeamProject
//
//  Created by Lab on 20.01.2022.
//

import Foundation

protocol PowerupsShopDataSourceDelegate{
    func powerupsLoaded()
}
