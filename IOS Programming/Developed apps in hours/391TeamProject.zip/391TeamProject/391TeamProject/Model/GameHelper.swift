//
//  GameHelper.swift
//  391TeamProject
//
//  Created by Lab on 20.01.2022.
//

import Foundation

struct GameHelper {
    var score = 500
    var totalPass = 10
    var totalUse2x = 10
    var numberOfSpins = 0
    var prevScore = 500
    
    init() {
        
    }
    
    mutating func use2XUsed() {
        totalUse2x -= 1
    }
    
    mutating func increaseNumberOfSpins() {
        numberOfSpins += 1
    }
    
    mutating func savePrevScore() {
        prevScore = score
    }
    
    mutating func resetGame() {
        score = 500
        totalPass = 10
        totalUse2x = 10
        numberOfSpins = 0
        prevScore = 500
    }
    
    func calculateScore(angle: Float) -> Int {
        let angle = angle.truncatingRemainder(dividingBy: Float.pi*2)

        if angle < Float.pi/4 {
            return 100
        }
        else if angle < Float.pi/2 {
            return 300
        }
        else if angle < 3*Float.pi/4 {
            return -300
        }
        else if angle < Float.pi {
            return -100
        }
        else if angle < 5*Float.pi/4 {
            return 500
        }
        else if angle < 6*Float.pi/4 {
            return -1*self.score
        }
        else if angle < 7*Float.pi/4 {
            return 4*self.score
        }
        else {
          return -100
        }
        
    }
}
