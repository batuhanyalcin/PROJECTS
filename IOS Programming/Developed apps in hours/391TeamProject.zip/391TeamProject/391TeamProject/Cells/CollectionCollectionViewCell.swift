//
//  collectionCollectionViewCell.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import UIKit

class CollectionCollectionViewCell: UICollectionViewCell {
    
    //Collection view screen cell labels buttons and image views
    
    @IBOutlet weak var quantityLabel: UILabel!
    @IBOutlet weak var powerupsImageView: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var buyButton: UIButton!
    
}
