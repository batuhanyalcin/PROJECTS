//
//  ViewController.swift
//  Batuhan_Yalcin_assignment2
//
//  Created by Lab on 16.10.2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var Enternumber: UILabel!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var play: UIButton!
    @IBOutlet weak var userInput: UITextField!
    
    let guessGameHelper = GuessGameHelper()
    override func viewDidLoad() {
        super.viewDidLoad()
        //resetGame()
        guessGameHelper.delegate=self
        guessGameHelper.createNumber()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func playGame(_ sender: Any) {
        print(guessGameHelper.printfunc())
        play.setTitle("Guess", for: .normal)
        let uservalue=userInput.text!
        let convertedUser=Int(uservalue)!
        status.text = guessGameHelper.calculateStatus(userNumber: convertedUser)
        image.image = UIImage(named: guessGameHelper.arrow(userNumber: convertedUser))
    }
    
    
    func resetGame() {
        play.setTitle("Play Again", for: .normal)
        status.text = "Guess a number between 1 to 10"
        image.image = UIImage(named: "guestion")
        guessGameHelper.createNumber()
    }
    


}
extension ViewController:GuessGameProtocol{
    func resetGuess() {
        resetGame()
    }
    
}
    

