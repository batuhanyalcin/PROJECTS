//
//  GuessGameProtocol.swift
//  Batuhan_Yalcin_assignment2
//
//  Created by Lab on 16.10.2021.
//

import Foundation

protocol GuessGameProtocol: AnyObject {
    func resetGuess()
}
