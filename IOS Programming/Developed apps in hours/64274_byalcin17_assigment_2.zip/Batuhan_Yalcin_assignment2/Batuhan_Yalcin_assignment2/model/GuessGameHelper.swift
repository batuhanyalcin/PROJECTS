//
//  GuessGameHelper.swift
//  Batuhan_Yalcin_assignment2
//
//  Created by Lab on 16.10.2021.
//

import Foundation
class GuessGameHelper {
    private var createdNumber:Int = 1
    //private var userNumber:Int = 0
    var countguess:Int=0
    weak var delegate : GuessGameProtocol?
    var flag:Bool=false
    init(){
        
    }
    func createNumber() {
         
        createdNumber=Int.random(in: 1..<11)
    }
    /*func calculateStatus(createdNumber:Int,Usernumber: Int) -> String {
        if (createdNumber>Usernumber) {
            return "Your guess is lower then the number"
        }else if (createdNumber<Usernumber) {
            return "Your guess is higher then the number"
        }else{
            return "Congruletions You hit the Number"
        }
    }*/
    func printfunc() -> String{
        return "The Created Number was this for try and win but if you loose use hint the next generated is this one \(createdNumber)"
    }
    
    func calculateStatus(userNumber:Int) -> String {
        count()
        if countguess==3 && !(createdNumber==userNumber) {
            self.delegate?.resetGuess()
            return "You Lost The Game Number Was: \(createdNumber)"

        }else{
            if countguess==0{
                
                return "Guess a number between 1 to 10"
            }else{
                if (createdNumber>userNumber) {
                    return "Your guess is lower then the number "
                }else if (createdNumber<userNumber) {
                    return "Your guess is higher then the number"
                }else{
                    flag=true
                    return "Congruletions You Hit the Number"
                }
            }

        }
    }
    
    func arrow (userNumber:Int) -> String {
        if countguess==3 {
            countguess-=4

            return "loose"
            
        }else{
            if countguess==0 {
                return "question"
            }else{
                if (createdNumber>userNumber) {
                    return "up2"
                }else if (createdNumber<userNumber) {
                    return "down2"
                }else{
                    return "target"
                }
            }
            
 
        }

    }
    
    
    func count(){
        if countguess==3 {
            countguess-=4
        }
        if flag{
            countguess = -1
            self.delegate?.resetGuess()
            flag=false
        }

        countguess+=1
        

        
    }
    
    
    
    
}
