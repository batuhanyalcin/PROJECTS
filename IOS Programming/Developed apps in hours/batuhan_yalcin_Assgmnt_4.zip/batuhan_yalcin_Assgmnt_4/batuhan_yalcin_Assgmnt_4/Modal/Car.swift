//
//  Car.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import Foundation


struct car {
    let carModel: String
    let imageName: String
    let price: Int
    let sold: Int
}

