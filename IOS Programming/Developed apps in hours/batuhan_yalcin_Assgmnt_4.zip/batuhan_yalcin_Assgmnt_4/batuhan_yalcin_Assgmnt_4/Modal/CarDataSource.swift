//
//  CarDataSource.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import Foundation

struct CarDataSource {
    private var carArray: [car] = []
    
    init () {
        carArray.append(car(carModel: "Chevrolet Corvette Stingray", imageName: "car1", price: 59995,sold: 108))
        
        carArray.append(car(carModel: "Aston Martin Vantage AMR", imageName: "car3", price: 17995,sold: 88))
        
        carArray.append(car(carModel: "Audi RS 6 Avant", imageName: "car2", price: 178500,sold: 89))
        
        carArray.append(car(carModel: "Bentley Continental GT V8", imageName: "car4", price: 198500,sold: 86))
        
        carArray.append(car(carModel: "BMW M8 Gran Coupe", imageName: "car5", price: 130000,sold: 80))
        
        carArray.append(car(carModel: "BMW X6 Vantablack Concept", imageName: "car6", price: 58000,sold: 75))
        
        carArray.append(car(carModel: "Emery Motorsports 1959", imageName: "car7", price: 78000,sold: 73))
        
        carArray.append(car(carModel: "Emory Motorsports 356 C4S “Allrad”", imageName: "car8", price: 258000,sold: 70))
        
        carArray.append(car(carModel: "Emory Motorsports 356 RSR", imageName: "car9", price: 198000,sold: 68))
        
        carArray.append(car(carModel: "Ferrari 812 GTS", imageName: "car10", price: 508000,sold: 67))
        
        carArray.append(car(carModel: "Ferrari Roma", imageName: "car11", price: 418000,sold: 66))
        
        carArray.append(car(carModel: "Ferrari SF90 Stradale", imageName: "car12", price: 512800,sold: 64))
        
        carArray.append(car(carModel: "Ford Mustang Shelby GT500", imageName: "car13", price: 72900,sold: 63))
        
        carArray.append(car(carModel: "Lamborghini Huracán Sterrato", imageName: "car14", price: 68000,sold: 61))
        
        carArray.append(car(carModel: "Land Rover Defender", imageName: "car15", price: 49900,sold: 54))
        
        carArray.append(car(carModel: "McLaren GT", imageName: "car16", price: 210000,sold: 48))
        
        carArray.append(car(carModel: "Mercedes-Maybach GLS 600", imageName: "car17", price: 58000,sold: 45))
        
        carArray.append(car(carModel: "Porsche 718 Cayman T", imageName: "car18", price: 66700,sold: 43))
        
        carArray.append(car(carModel: "Porsche Boxster Bergspyder", imageName: "car19", price: 158000,sold: 41))
        
        carArray.append(car(carModel: "Porsche Taycan", imageName: "car20", price: 103800,sold: 28))
        
        carArray.append(car(carModel: "Tesla Cybertruck", imageName: "car21", price: 39900,sold: 19))
        
    }
    
    func getNumberOfCars() -> Int {
        return carArray.count
    }
    
    func getCarWithIndex(index: Int) -> car {
        return carArray[index]
    }
}


