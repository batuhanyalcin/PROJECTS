//
//  topSellerViewController.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import UIKit

class topSellerViewController: UIViewController {
    
    let carDataSource = CarDataSource()

    @IBOutlet weak var TopSellerTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Top 10 List"

        // Do any additional setup after loading the view.
    }
    

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let cell = sender as! topSellerTableViewCell
        if let indexPath = self.TopSellerTableView.indexPath(for: cell) {
            let car = carDataSource.getCarWithIndex(index: getRealIndex(indexPath: indexPath))
            let detailViewController = segue.destination as! detailViewController
            detailViewController.selectedCar = car
        }
    }
    
    func getRealIndex(indexPath: IndexPath) -> Int {
        let realIndex = indexPath.row.quotientAndRemainder(dividingBy: carDataSource.getNumberOfCars()).remainder
        return realIndex
    }
}

extension topSellerViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return playerDataSource.getNumberOfPlayers()
        if (section == 0) {
            return 10
        } else if (section == 1) {
            return 50
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TopTenCell", for: indexPath) as! topSellerTableViewCell
        let car = carDataSource.getCarWithIndex(index: getRealIndex(indexPath: indexPath))
        cell.carImageView.image = UIImage(named: car.imageName)
        cell.carModelLabel.text = car.carModel
        return cell
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
