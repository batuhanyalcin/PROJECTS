//
//  detailViewController.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import UIKit

class detailViewController: UIViewController {
    
    var selectedCar: car?

    //@IBOutlet weak var carModelLabel: UILabel!
    @IBOutlet weak var carImageView: UIImageView!
    @IBOutlet weak var carPriceLabel: UILabel!
    @IBOutlet weak var carSoldLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = selectedCar?.carModel
        if let Car = selectedCar {
            self.carPriceLabel.text = "\(Car.price)"
            self.carSoldLabel.text = "\(Car.sold)"
            self.carImageView.image = UIImage(named: Car.imageName)
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
