//
//  collectionViewController.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import UIKit

class collectionViewController: UIViewController {
    
    let carDataSource = CarDataSource()


   
    @IBOutlet weak var CarCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let item = sender as! collectionCollectionViewCell
        if let indexPath = self.CarCollectionView.indexPath(for: item) {
            let realIndex = indexPath.row.quotientAndRemainder(dividingBy: carDataSource.getNumberOfCars()).remainder
            let car = carDataSource.getCarWithIndex(index: realIndex)
            
            let detailViewController = segue.destination as! detailViewController
            detailViewController.selectedCar = car
        }
    }
    
}

extension collectionViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1000
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewCell", for: indexPath) as! collectionCollectionViewCell
        
        let realIndex = indexPath.row.quotientAndRemainder(dividingBy: carDataSource.getNumberOfCars()).remainder
        let car = carDataSource.getCarWithIndex(index: realIndex)
        item.carImageView.image = UIImage(named: car.imageName)
        item.carModelLabel.text = car.carModel
        return item
    }
    
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
