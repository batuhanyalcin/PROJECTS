//
//  topSellerTableViewCell.swift
//  batuhan_yalcin_Assgmnt_4
//
//  Created by Lab on 7.11.2021.
//

import UIKit

class topSellerTableViewCell: UITableViewCell {
    
   
    
    @IBOutlet weak var carModelLabel: UILabel!
    @IBOutlet weak var carImageView: UIImageView!
    
  
    
    //  @IBOutlet weak var playerNameLabel: UILabel!
  //  @IBOutlet weak var playerImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
}
