//
//  ViewController.swift
//  batuhan_yalcin_assg3
//
//  Created by Lab on 27.10.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

