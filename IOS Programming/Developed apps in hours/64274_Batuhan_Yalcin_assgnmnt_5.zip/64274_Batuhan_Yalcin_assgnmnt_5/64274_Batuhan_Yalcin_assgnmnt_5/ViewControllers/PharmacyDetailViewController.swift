//
//  PharmacyDetailViewController.swift
//  64274_Batuhan_Yalcin_assgnmnt_5
//
//  Created by Lab on 25.11.2021.
//

import UIKit

class PharmacyDetailViewController: UIViewController {

    var selectedPharmacyId: String?
    var pharmacyDetailDataSource = PharmacyDataSource()
    
 
    @IBOutlet weak var adressLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pharmacyDetailDataSource.delegate = self
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        if let pharmacyId = selectedPharmacyId {
            pharmacyDetailDataSource.loadPharmacyDetail(pharmacyId: pharmacyId)
        }
    }
    


}

extension PharmacyDetailViewController: PharmacyDataSourceDelegate {
    func pharmacyListLoaded() {}
    
    func pharmacyDetailLoaded(pharmacy: PharmacyDetailStruct) {
        self.title = pharmacy.Name
        self.adressLabel.text = "Adress: \(pharmacy.Address)"
        self.phoneLabel.text = "Phone: \(pharmacy.Phone)"
    }
}
