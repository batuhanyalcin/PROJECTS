//
//  PharmacyViewController.swift
//  64274_Batuhan_Yalcin_assgnmnt_5
//
//  Created by Lab on 25.11.2021.
//

import UIKit

class PharmacyViewController: UIViewController {

    @IBOutlet weak var pharmacyTableView: UITableView!
    
    var selectedRegionId: String?
    var pharmacyDataSource = PharmacyDataSource()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        pharmacyDataSource.delegate = self
        
    }
    override func viewWillAppear(_ animated: Bool) {
        if let regionId = selectedRegionId {
            pharmacyDataSource.loadPharmacyList(regionId: regionId)
        }
    }
    let myBlue = UIColor(red: 62.0/255, green: 174.0/255, blue: 206.0/255, alpha: 1.0)
    let myGreen = UIColor(red: 110.0/255, green: 186.0/255, blue: 64.0/255, alpha: 1.0)
    let myRed = UIColor(red: 247.0/255, green: 118.0/255, blue: 113.0/255, alpha: 1.0)
    let myYellow = UIColor(red: 255.0/255, green: 190.0/255, blue: 106.0/255, alpha: 1.0)
    
    //myLabel.backgroundColor = random([myBlue, myRed, myGreen, myYellow])
    
    func random(colors: [UIColor]) -> UIColor {
        return colors[Int(arc4random_uniform(UInt32(colors.count)))]

    }
    
        
        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
            let cell = sender as! PharmacyTableViewCell
            if let indexPath = self.pharmacyTableView.indexPath(for: cell) {
                let pharmacy = pharmacyDataSource.getPharmacyWithIndex(index: getRealIndex(indexPath: indexPath))
                let pharmacyDetailViewController = segue.destination as! PharmacyDetailViewController
                pharmacyDetailViewController.selectedPharmacyId = pharmacy.Id
            }
        }
        
        func getRealIndex(indexPath: IndexPath) -> Int {
            if (pharmacyDataSource.getNumberOfPharmacy() == 0) {
                return 0;
            }
            let realIndex = indexPath.row.quotientAndRemainder(dividingBy: pharmacyDataSource.getNumberOfPharmacy()).remainder
            return realIndex
        }
    }

    extension PharmacyViewController: PharmacyDataSourceDelegate {
        func pharmacyListLoaded() {
            pharmacyTableView.reloadData()
        }
        func pharmacyDetailLoaded(pharmacy: PharmacyDetailStruct) {}
    }

    extension PharmacyViewController: UITableViewDataSource {
        func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return pharmacyDataSource.getNumberOfPharmacy()
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PharmacyCell", for: indexPath) as! PharmacyTableViewCell
            
            let region = pharmacyDataSource.getPharmacyWithIndex(index: getRealIndex(indexPath: indexPath))
            cell.pharmacyNameLabel.text = region.Name
            cell.pharmacyNameLabel.backgroundColor = random(colors: [myBlue, myRed, myGreen, myYellow])
            return cell
        }
        

    }

    extension PharmacyViewController: UIScrollViewDelegate {
 
        func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
            if (velocity.y != 0 || velocity.x != 0) {
                let reminder = targetContentOffset.pointee.y.truncatingRemainder(dividingBy: 90.5)
                let previousPoint = targetContentOffset.pointee
                targetContentOffset.pointee = CGPoint(x: previousPoint.x, y: previousPoint.y - reminder)
            }
        }
    }

    
    





