//
//  CityViewController.swift
//  64274_Batuhan_Yalcin_assgnmnt_5
//
//  Created by Lab on 25.11.2021.
//

import UIKit

class CityViewController: UIViewController {

    

    var cityDataSource = CityDataSource()
    
    @IBOutlet weak var cityTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        cityDataSource.delegate = self
        cityDataSource.loadCityList()
    }
    let myBlue = UIColor(red: 62.0/255, green: 174.0/255, blue: 206.0/255, alpha: 1.0)
    let myGreen = UIColor(red: 110.0/255, green: 186.0/255, blue: 64.0/255, alpha: 1.0)
    let myRed = UIColor(red: 247.0/255, green: 118.0/255, blue: 113.0/255, alpha: 1.0)
    let myYellow = UIColor(red: 255.0/255, green: 190.0/255, blue: 106.0/255, alpha: 1.0)
    
    
    func random(colors: [UIColor]) -> UIColor {
        return colors[Int(arc4random_uniform(UInt32(colors.count)))]

    }
    
        
        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
            let cell = sender as! CityTableViewCell
            if let indexPath = self.cityTableView.indexPath(for: cell) {
                let location = cityDataSource.getCityWithIndex(index: getRealIndex(indexPath: indexPath))
                let regionViewController = segue.destination as! RegionViewController
                regionViewController.selectedCityId = location.Id
            }
        }
        
        func getRealIndex(indexPath: IndexPath) -> Int {
            if (cityDataSource.getNumberOfCity() == 0) {
                return 0;
            }
            let realIndex = indexPath.row.quotientAndRemainder(dividingBy: cityDataSource.getNumberOfCity()).remainder
            return realIndex
        }
    }

    extension CityViewController: CityDataSourceDelegate {
        func cityListLoaded() {
            cityTableView.reloadData()
        }
    }

    extension CityViewController: UITableViewDataSource {
        func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return cityDataSource.getNumberOfCity()
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CityCell", for: indexPath) as! CityTableViewCell
            
            let city = cityDataSource.getCityWithIndex(index: getRealIndex(indexPath: indexPath))
            cell.cityNameLabel.text = city.Name
            cell.cityNameLabel.backgroundColor = random(colors: [myBlue, myRed, myGreen, myYellow])
            return cell
        }
        
    }

    extension CityViewController: UIScrollViewDelegate {

        func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
            if (velocity.y != 0 || velocity.x != 0) {
                let reminder = targetContentOffset.pointee.y.truncatingRemainder(dividingBy: 90.5)
                let previousPoint = targetContentOffset.pointee
                targetContentOffset.pointee = CGPoint(x: previousPoint.x, y: previousPoint.y - reminder)
            }
        }
    }

    
    


