//
//  LocationDataSource.swift
//  64274_Batuhan_Yalcin_assgnmnt_5
//
//  Created by Lab on 25.11.2021.
//

import Foundation
import UIKit

class PharmacyDataSource {
    private var pharmacyArray: [PharmacyStruct] = []
    private var pharmacyDetailArray: [PharmacyDetailStruct] = []
    private let baseURL = "https://koc.api.staging.tarentum.io"
    var delegate: PharmacyDataSourceDelegate?
    
    init () {
    }
    
    func getNumberOfPharmacy() -> Int {
        return pharmacyArray.count
    }
    
    func getPharmacyWithIndex(index: Int) -> PharmacyStruct {
        return pharmacyArray[index]
    }
    
    func loadPharmacyList(regionId: String) {
        let urlSession = URLSession.shared
        if let url = URL(string: "\(baseURL)/region/\(regionId)/pharmacy") {
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "GET"
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let dataTask = urlSession.dataTask(with: urlRequest) { data, response, error in
                let decoder = JSONDecoder()
                if let data = data {
                    let pharmacyArrayFromNetwork = try! decoder.decode([PharmacyStruct].self, from: data)
                    self.pharmacyArray = pharmacyArrayFromNetwork
                    DispatchQueue.main.async {
                        self.delegate?.pharmacyListLoaded()
                    }
                    
                }
            }
            dataTask.resume()
        }
    }
    
    
    func loadPharmacyDetail(pharmacyId: String) {
        let urlSession = URLSession.shared
        if let url = URL(string: "\(baseURL)/pharmacy/\(pharmacyId)") {
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "GET"
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let dataTask = urlSession.dataTask(with: urlRequest) { data, response, error in
                let decoder = JSONDecoder()
                if let data = data {
                    let pharmacyDetailArrayFromNetwork = try! decoder.decode(PharmacyDetailStruct.self, from: data)
                    //self.pharmacyDetailArray = pharmacyDetailArrayFromNetwork
                    DispatchQueue.main.async {
                        self.delegate?.pharmacyDetailLoaded(pharmacy: pharmacyDetailArrayFromNetwork)
                    }
                }
            }
            dataTask.resume()
        }
    }
    
    
    
    
}
