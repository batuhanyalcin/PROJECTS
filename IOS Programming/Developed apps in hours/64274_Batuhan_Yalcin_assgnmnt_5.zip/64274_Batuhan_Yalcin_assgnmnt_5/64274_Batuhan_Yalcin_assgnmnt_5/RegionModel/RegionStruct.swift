//
//  RegionStruct.swift
//  64274_Batuhan_Yalcin_assgnmnt_5
//
//  Created by Lab on 25.11.2021.
//

import Foundation

struct RegionStruct: Codable{
    let Id: String
    let Name: String
}
