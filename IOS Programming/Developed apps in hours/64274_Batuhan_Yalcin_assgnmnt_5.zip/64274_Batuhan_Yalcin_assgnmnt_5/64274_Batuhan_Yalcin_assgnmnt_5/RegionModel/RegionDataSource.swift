//
//  RegionDataSource.swift
//  64274_Batuhan_Yalcin_assgnmnt_5
//
//  Created by Lab on 25.11.2021.
//


import Foundation
import UIKit

class RegionDataSource {
    private var regionArray: [RegionStruct] = []
    private let baseURL = "https://koc.api.staging.tarentum.io"
    var delegate: RegionDataSourceDelegate?
    
    init () {
    }
    
    func getNumberOfRegion() -> Int {
        return regionArray.count
    }
    
    func getRegionWithIndex(index: Int) -> RegionStruct {
        return regionArray[index]
    }
    
    func loadRegionList(cityId: Int) {
        let urlSession = URLSession.shared
        if let url = URL(string: "\(baseURL)/city/\(cityId)/region") {
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "GET"
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let dataTask = urlSession.dataTask(with: urlRequest) { data, response, error in
                let decoder = JSONDecoder()
                if let data = data {
                    let regionArrayFromNetwork = try! decoder.decode([RegionStruct].self, from: data)
                    self.regionArray = regionArrayFromNetwork
                    DispatchQueue.main.async {
                        self.delegate?.regionListLoaded()
                    }
                    
                }
            }
            dataTask.resume()
        }
    }
    
}
