//
//  LocationDataSource.swift
//  64274_Batuhan_Yalcin_assgnmnt_5
//
//  Created by Lab on 25.11.2021.
//

import Foundation
import UIKit

class CityDataSource {
    private var cityArray: [CitiesStruct] = []
    private let baseURL = "https://koc.api.staging.tarentum.io"
    var delegate: CityDataSourceDelegate?
    
    init () {
    }
    
    func getNumberOfCity() -> Int {
        return cityArray.count
    }
    
    func getCityWithIndex(index: Int) -> CitiesStruct {
        return cityArray[index]
    }
    
    func loadCityList() {
        let urlSession = URLSession.shared
        if let url = URL(string: "\(baseURL)/city") {
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "GET"
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let dataTask = urlSession.dataTask(with: urlRequest) { data, response, error in
                let decoder = JSONDecoder()
                if let data = data {
                    let cityArrayFromNetwork = try! decoder.decode([CitiesStruct].self, from: data)
                    self.cityArray = cityArrayFromNetwork
                    DispatchQueue.main.async {
                        self.delegate?.cityListLoaded()
                    }
                    
                }
            }
            dataTask.resume()
        }
    }
    
}
