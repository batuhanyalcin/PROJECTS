//
//  CityDataSourceDelegate.swift
//  64274_Batuhan_Yalcin_assgnmnt_5
//
//  Created by Lab on 25.11.2021.
//

import Foundation
import Foundation
protocol CityDataSourceDelegate {
    func cityListLoaded()
}

